<?php

class sipParser {
    
    private $ch;
    private $default_arr;
    function __construct(){
        $this->ch = curl_init();
        curl_setopt_array($this->ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ));
        
        $this->default_arr = ["reliability"=>4,
                              "priority"=>2, 
                              "activity"=>"SIP service attack",
                              "sub_category"=>"undefined",
                              "country"=>"unknown",
                              "city"=>"unknown",
                              "lat"=>0.0,
                              "long"=>0.0,
                              "source"=>"unknown",
                              "target"=>"unknown",
                              "dest_port"=>0,
                              "last_online"=>0,
                              "first_seeen"=>0,
                              "used_by"=>"unknown",
                              "reference_link"=>"undefined"];
    }
    
    function getData(){
        $url = "https://lists.blocklist.de/lists/sip.txt";
        curl_setopt($this->ch, CURLOPT_URL, $url);
        $data = curl_exec($this->ch);
        $data_arr = explode("\n", $data);
        $res_arr = [];
        foreach($data_arr as $ip){
            if(!empty($ip)){
                //$this->getLocation($ip);
                $res_arr[$ip] = $this->default_arr;
            }
        }
        curl_close($this->ch);
        echo json_encode($res_arr);
    }
    
    public function getLocation($ip){
        curl_setopt($this->ch, CURLOPT_URL, "https://freegeoip.app/json/".$ip);
        $ip_data = curl_exec($this->ch);
        if($ip_data){
            $ip_data = json_decode($ip_data);
            if(!empty(trim($ip_data->city))){
                $this->default_arr['city'] = $ip_data->city;
            }
            if(!empty(trim($ip_data->country_name))){
                $this->default_arr['country'] = $ip_data->country_name;
            }
            if(!empty(trim($ip_data->latitude)) && !empty(trim($ip_data->longitude))){
                $this->default_arr['lat'] = $ip_data->latitude;
                $this->default_arr['long'] = $ip_data->longitude;
            }
        }
    }
}
$op = new sipParser();
 $op->getData();

?>
