<?php
class otxParser {
    
    private $ch;
    private $default_arr;
    function __construct(){
        $this->ch = curl_init();
        curl_setopt_array($this->ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ));
        
        $this->default_arr = ["reliability"=>5,
                              "priority"=>7, 
                              "activity"=>"strongips",
                              "sub_category"=>"undefined",
                              "country"=>"unknown",
                              "city"=>"unknown",
                              "lat"=>0.0,
                              "long"=>0.0,
                              "source"=>"unknown",
                              "target"=>"unknown",
                              "dest_port"=>0,
                              "last_online"=>0,
                              "first_seeen"=>0,
                              "used_by"=>"unknown",
                              "reference_link"=>"undefined"];
    }
    
    function getData(){
        $url = "https://reputation.alienvault.com/reputation.data";
        curl_setopt($this->ch, CURLOPT_URL, $url);
        $data = curl_exec($this->ch);
        $data_arr = explode("\n", $data);
        $res_arr = [];
        foreach($data_arr as $details){
            $details = explode("#", $details);
            if(count($details) > 1){
                $ip = $details[0];
                if(!empty($details[1]))
                    $this->default_arr['reliability'] = $details[1];
                if(!empty($details[2]))
                    $this->default_arr['priority'] = $details[2];
                if(!empty($details[3]))
                    $this->default_arr['activity'] = $details[3];
                if(!empty($details[4]))
                    $this->default_arr['country'] = $details[4];
                if(!empty($details[5]))
                    $this->default_arr['city'] = $details[5];
                if(!empty($details[6])){
                    $cord_arr =explode(",", $details[6]);
                    $this->default_arr['lat'] = $cord_arr[0];
                    $this->default_arr['long'] = $cord_arr[1];
                }
                
                $res_arr[$ip] = $this->default_arr;
            }
        }
        echo json_encode($res_arr);
    }
}
$op = new otxParser();
$op->getData();

?>