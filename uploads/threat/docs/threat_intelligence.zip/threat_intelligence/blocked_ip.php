<?php
        $host = 'localhost';
        $user = 'dev';
        $password = 'leo_1234';
        $database = 'siem_license';
        $conn = mysqli_connect($host, $user, $password, $database);

        //api url to get ip location
        //http://www.geoplugin.net/json.gp?ip=46.246.124.162
        
        // Check connection
        if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit;
        }
        $source_ulr_arr = ['apache'=>'https://lists.blocklist.de/lists/apache.txt',
                            'bots'=>'https://lists.blocklist. de/lists/bots.txt'];
        
        foreach($source_ulr_arr as $source_url){
            $data = file_get_contents($source_url);
        }
//        foreach($source_ulr_arr as $source=>$source_url){
//            $data = "('";
//            $data .= file_get_contents($source_url);
//            $data .= "')";
//            $data = preg_replace('/\n/', "'),('", $data);
//            $maketemp = "CREATE TEMPORARY TABLE temp_table(`ip` varchar(50) NOT NULL)";
//            $conn->query($maketemp) or die ("Sql error : ".mysql_error());
//            $inserttemp = "INSERT INTO temp_table(`ip`) VALUES $data";
//            $conn->query($inserttemp) or die ("Sql error : ".mysql_error());
//            $select = "SELECT t.ip FROM temp_table t   LEFT JOIN blocked_ips bi ON t.ip = bi.ip WHERE bi.ip IS NULL LIMIT 1";
//            $result = $conn->query($select) or die ("Sql error : ".mysql_error());
//            if ($result->num_rows > 0) {
//                // output data of each row
//                while($row = $result->fetch_assoc()) {
//                    echo "'".$row['ip']."',";
//                }
//            } else {
//                echo "error: %s\n", mysqli_error($conn);
//                echo "else 0 results";
//            }
//              exit;
//
//            print_r($data);exit;
//        }
        $conn->close();

?>