<?php
    class blocklistParser {
    
        private $ch;
        private $default_arr;
        function __construct(){
            $this->ch = curl_init();
            curl_setopt_array($this->ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER         => false,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
            ));

            $this->default_arr = ["domain"=>"unknown", 
                                  "filename"=>"unknown",
                                  "file_type"=>"unknown",
                                  "priority"=>"medium",
                                  "country"=>"unknown",
                                  "url_status"=>"unknown",
                                  "date_added"=>"",
                                  "threat_type"=>"ransomware",
                                  "threat_tag"=>"unknown"
                                 ];
        }
    
        function getData(){
            $url = "https://blocklist.site/app/dl/ransomware";
            curl_setopt($this->ch, CURLOPT_URL, $url);
            $data = (curl_exec($this->ch));
            $data_arr = explode("\n", $data);
            $data_arr = array_slice($data_arr, 2);
            $res = [];
            foreach($data_arr as $url){
                if(!empty(trim($url))){
                    if(!preg_match("/http/", $url)){
                        $url = "http://".$url;
                    }
                    $res[$url] = $this->default_arr;
                }
                curl_close($this->ch);
            }
            echo json_encode($res);
        }
    }
$op = new blocklistParser();
$op->getData();
?>